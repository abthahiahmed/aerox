#include "data.hpp"

vector<Post> posts = {
    {
        "How to make apps in Flutter",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "19/08/2025"
    }, 
    {
        "How to solve problems on AlgoRux", 
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "20/08/2025"
    },
    {
        "Code optimization",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "21/08/2025"
    },
    {
        "Cheatsheet for React",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        "22/08/2025"
    }
};