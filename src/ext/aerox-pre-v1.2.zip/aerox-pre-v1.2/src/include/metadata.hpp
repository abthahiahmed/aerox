#ifndef METADATA_HPP
#define METADATA_HPP
#include <iostream>
using namespace std;
extern string __title__;
extern string __description__;
#endif

