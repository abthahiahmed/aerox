#ifndef DOCUMENT_HPP
#define DOCUMENT_HPP

#include <iostream>
#include "metadata.hpp"
using namespace std;


extern string Head();
extern string AScript();


#endif