@component Footer(){
    return <><p>This is footer!</p><>
}