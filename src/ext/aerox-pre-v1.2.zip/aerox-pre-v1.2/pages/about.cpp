@page About(Request req){
    @title = "About Us";
    @description = "This is all about me";

    return <>
    {Header()}
        <h1>C++ Web Server framework by Abthahi Ahmed Rifat</h1>
    {Footer()}
    <>;
}